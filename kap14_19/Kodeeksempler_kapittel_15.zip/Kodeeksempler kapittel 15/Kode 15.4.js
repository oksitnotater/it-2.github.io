// Sorterer de brukte bokstavene
brukteBokstaver.sort();
 
// Skriver ut informasjon om brukte bokstaver, 
// riktige bokstaver og antall sjanser igjen
brukteBokstaverEl.innerHTML = "Brukte bokstaver: " + brukteBokstaver;	
riktigeBokstaverEl.innerHTML = "Riktige bokstaver: " + riktigeBokstaver;	
sjanserIgjenEl.innerHTML = "Antall sjanser igjen: " + antallSjanser;	