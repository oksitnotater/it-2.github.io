if (antallSjanser === 5) {
  tegnHode();
} else if (antallSjanser === 4) {
  tegnKropp();
} else if (antallSjanser === 3) {
  tegnVenstreArm();
} else if (antallSjanser === 2) {
  tegnHoyreArm();
} else if (antallSjanser === 1) {
  tegnVenstreBein();
} else if (antallSjanser === 0) {
  tegnHoyreBein();
  alert("Du tapte!");
}